// netlify/functions/unsubscribe.js
//
// Called when someone clicks "Unsubscribe here" in an email — this one
// stays a plain public link (no sign-in required), same as virtually
// every newsletter unsubscribe link, since requiring login just to opt
// out is bad practice. It only ever turns subscribed OFF for that email,
// never anything more.

const { unsubscribeByEmail } = require("./db");

exports.handler = async (event) => {
  try {
    const email = event.queryStringParameters?.email;

    if (!email) {
      return { statusCode: 400, body: "Missing email" };
    }

    await unsubscribeByEmail(email);

    return {
      statusCode: 200,
      headers: { "Content-Type": "text/html" },
      body: `<p style="font-family: sans-serif;">You're unsubscribed. Sorry to see you go — you can always opt back in from Cloud Account in the app.</p>`,
    };
  } catch (err) {
    console.error("BeanScore: unsubscribe failed", err);
    return { statusCode: 500, body: "Something went wrong" };
  }
};
