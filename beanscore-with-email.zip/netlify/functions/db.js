// netlify/functions/db.js
//
// Subscriber storage for the weekly coffee newsletter. Uses the same
// Netlify DB (Postgres, via Neon's serverless driver) that reviews.js
// already uses — no new service to set up, no new env vars beyond what
// Netlify DB already provides automatically.
//
// user_metadata.newsletterOptIn (set by the app via Netlify Identity)
// is what the UI reads to show the toggle state, but it isn't something
// a scheduled function can easily list in bulk. This table is the
// queryable mirror of that same preference, kept in sync by
// newsletter.js every time someone flips the toggle.

const { neon } = require("@netlify/neon");

const sql = neon(); // reads the NETLIFY_DATABASE_URL env var Netlify DB sets automatically

let tableReady = null;
function ensureTable() {
  if (!tableReady) {
    tableReady = (async () => {
      await sql`
        CREATE TABLE IF NOT EXISTS newsletter_subscribers (
          user_id TEXT PRIMARY KEY,
          email TEXT NOT NULL,
          subscribed BOOLEAN NOT NULL DEFAULT true,
          updated_at BIGINT NOT NULL
        )
      `;
      await sql`CREATE INDEX IF NOT EXISTS newsletter_subscribed_idx ON newsletter_subscribers (subscribed)`;
    })();
  }
  return tableReady;
}

// Returns the row as it was BEFORE this update, so the caller can tell
// whether this is a brand-new opt-in (to decide whether to send the
// welcome email) versus someone just re-confirming an existing one.
async function upsertSubscriber(userId, email, subscribed) {
  await ensureTable();
  const existing = await sql`SELECT subscribed FROM newsletter_subscribers WHERE user_id = ${userId}`;
  await sql`
    INSERT INTO newsletter_subscribers (user_id, email, subscribed, updated_at)
    VALUES (${userId}, ${email}, ${subscribed}, ${Date.now()})
    ON CONFLICT (user_id) DO UPDATE
      SET email = EXCLUDED.email, subscribed = EXCLUDED.subscribed, updated_at = EXCLUDED.updated_at
  `;
  const wasSubscribed = existing.length > 0 && existing[0].subscribed === true;
  return { wasSubscribed };
}

async function unsubscribeByEmail(email) {
  await ensureTable();
  await sql`UPDATE newsletter_subscribers SET subscribed = false, updated_at = ${Date.now()} WHERE email = ${email}`;
}

async function getActiveSubscribers() {
  await ensureTable();
  return sql`SELECT user_id, email FROM newsletter_subscribers WHERE subscribed = true`;
}

module.exports = { upsertSubscriber, unsubscribeByEmail, getActiveSubscribers };
