// netlify/functions/reviews.js
//
// The only way the app ever touches the database. Postgres has no
// per-user client-side security rules the way Firestore did, so this
// function is what enforces "you only ever see and change your own rows" —
// every query below is filtered by the signed-in user's id, taken from the
// Netlify Identity JWT, never from anything the client sends.
//
// Netlify auto-populates `context.clientContext.user` for classic
// functions like this one whenever the request carries a valid Identity
// access token as `Authorization: Bearer <token>` — which is exactly what
// CloudSync.authHeaders() sends from the app. No manual JWT handling here.
//
// Data lives in one `reviews` table in Netlify DB (Postgres, via Neon's
// serverless driver). The table is created on first use, so there's no
// separate migration step to run by hand.

const { neon } = require("@netlify/neon");

const sql = neon(); // reads the NETLIFY_DATABASE_URL env var Netlify DB sets automatically

let tableReady = null;
function ensureTable() {
  if (!tableReady) {
    tableReady = (async () => {
      await sql`
        CREATE TABLE IF NOT EXISTS reviews (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          created_at BIGINT NOT NULL,
          data JSONB NOT NULL
        )
      `;
      await sql`CREATE INDEX IF NOT EXISTS reviews_user_id_idx ON reviews (user_id)`;
    })();
  }
  return tableReady;
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  };
}

exports.handler = async (event, context) => {
  const user = context.clientContext && context.clientContext.user;
  if (!user || !user.sub) {
    return json(401, { error: "Sign in required." });
  }
  const userId = user.sub;

  try {
    await ensureTable();

    // Requests to /.netlify/functions/reviews/<id> are forwarded to this
    // same function with the id left on the path — pull it off manually.
    const segments = event.path.split("/").filter(Boolean);
    const fnIndex = segments.indexOf("reviews");
    const idFromPath = fnIndex >= 0 ? segments[fnIndex + 1] : undefined;

    if (event.httpMethod === "GET") {
      const rows = await sql`SELECT data FROM reviews WHERE user_id = ${userId}`;
      return json(200, rows.map((r) => r.data));
    }

    if (event.httpMethod === "POST") {
      let review;
      try {
        review = JSON.parse(event.body || "{}");
      } catch (e) {
        return json(400, { error: "Invalid JSON body." });
      }
      if (!review || !review.id) {
        return json(400, { error: "Review is missing an id." });
      }
      const createdAt = Number(review.createdAt) || Date.now();
      // ON CONFLICT ... WHERE keeps someone from ever overwriting a review
      // that belongs to a different account, even if two ids ever collided.
      await sql`
        INSERT INTO reviews (id, user_id, created_at, data)
        VALUES (${review.id}, ${userId}, ${createdAt}, ${JSON.stringify(review)}::jsonb)
        ON CONFLICT (id) DO UPDATE
          SET data = EXCLUDED.data, created_at = EXCLUDED.created_at
          WHERE reviews.user_id = ${userId}
      `;
      return json(200, { ok: true });
    }

    if (event.httpMethod === "DELETE") {
      if (!idFromPath) return json(400, { error: "Missing review id." });
      await sql`DELETE FROM reviews WHERE id = ${idFromPath} AND user_id = ${userId}`;
      return json(200, { ok: true });
    }

    return json(405, { error: "Method not allowed." });
  } catch (e) {
    console.error("BeanScore reviews function error:", e);
    return json(500, { error: "Server error." });
  }
};
