// netlify/functions/coffee-tips.js

const COFFEE_TIPS = [
  "Water just off the boil (about 195–205°F) pulls out the best flavor — full boiling water can scorch your grounds and make coffee taste bitter.",
  "Whole beans stay fresh far longer than pre-ground coffee. If you can, grind right before you brew.",
  "A burr grinder gives a much more even grind than a blade grinder — and even grounds mean more even extraction, which means better-tasting coffee.",
  "Coffee is roughly 98% water, so if your tap water tastes off, your coffee will too. Filtered water makes a noticeable difference.",
  "Store your beans in an airtight container away from light and heat — not the fridge or freezer, which introduce moisture and odors.",
  "The 'first crack' sound during roasting is when beans hit light roast territory — it's the same idea as popcorn popping.",
  "A darker roast doesn't mean more caffeine. Lighter roasts actually retain slightly more caffeine per bean by weight.",
  "If your pour-over tastes sour, try a finer grind or slightly hotter water — sourness is usually a sign of under-extraction.",
  "Bloom your grounds: pour a small amount of water first and let it sit 30 seconds before continuing. It releases trapped CO2 for a more even brew.",
  "Coffee beans are technically seeds from the fruit of the coffee plant — the fruit itself is called a cherry.",
];

function getRandomTip() {
  const index = Math.floor(Math.random() * COFFEE_TIPS.length);
  return COFFEE_TIPS[index];
}

function getFirstTip() {
  return COFFEE_TIPS[0];
}

module.exports = { getRandomTip, getFirstTip, COFFEE_TIPS };
