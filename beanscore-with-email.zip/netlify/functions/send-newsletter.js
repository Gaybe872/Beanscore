// netlify/functions/send-newsletter.js
// Scheduled: runs every Monday 8am UTC, sends the weekly template to
// everyone currently marked subscribed = true in Netlify DB.

const { sendViaEmailJS } = require("./send-email");
const { getRandomTip } = require("./coffee-tips");
const { getActiveSubscribers } = require("./db");

exports.handler = async () => {
  if (!process.env.EMAILJS_SERVICE_ID || !process.env.EMAILJS_PRIVATE_KEY) {
    console.log("EmailJS not configured yet — skipping newsletter run.");
    return { statusCode: 200, body: "Skipped: not configured" };
  }

  const siteUrl = process.env.URL || "https://beanscore.netlify.app";
  const subscribers = await getActiveSubscribers();
  const tip = getRandomTip();
  let sent = 0;
  let failed = 0;

  for (const sub of subscribers) {
    try {
      await sendViaEmailJS({
        templateId: process.env.EMAILJS_WEEKLY_TEMPLATE_ID,
        toEmail: sub.email,
        coffeeTip: tip,
        unsubscribeUrl: `${siteUrl}/.netlify/functions/unsubscribe?email=${encodeURIComponent(sub.email)}`,
      });
      sent++;
    } catch (err) {
      console.error(`Failed to email ${sub.email}:`, err.message);
      failed++;
    }
  }

  console.log(`Newsletter run complete: ${sent} sent, ${failed} failed.`);
  return { statusCode: 200, body: JSON.stringify({ sent, failed }) };
};
