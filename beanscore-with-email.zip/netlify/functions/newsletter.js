// netlify/functions/newsletter.js
//
// Called by the app whenever someone toggles the newsletter switch (both
// on first sign-up via the consent gate, and later from Cloud Account).
// Mirrors reviews.js's security model exactly: the caller's identity
// comes only from the verified Netlify Identity JWT in
// context.clientContext.user — never from anything the client sends in
// the request body. This is what keeps the subscriber table in sync with
// user_metadata.newsletterOptIn so send-newsletter.js has something to
// query in bulk.

const { upsertSubscriber } = require("./db");
const { sendViaEmailJS } = require("./send-email");
const { getFirstTip } = require("./coffee-tips");

function json(statusCode, body) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}

exports.handler = async (event, context) => {
  const user = context.clientContext && context.clientContext.user;
  if (!user || !user.sub || !user.email) {
    return json(401, { error: "Sign in required." });
  }

  if (event.httpMethod !== "POST") {
    return json(405, { error: "Method not allowed." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return json(400, { error: "Invalid JSON body." });
  }

  const subscribed = !!body.subscribed;

  try {
    const { wasSubscribed } = await upsertSubscriber(user.sub, user.email, subscribed);

    // Only send the welcome email on a genuinely new opt-in — not every
    // time someone re-saves the same "on" state.
    const isNewOptIn = subscribed && !wasSubscribed;
    if (isNewOptIn && process.env.EMAILJS_SERVICE_ID) {
      try {
        await sendViaEmailJS({
          templateId: process.env.EMAILJS_WELCOME_TEMPLATE_ID,
          toEmail: user.email,
          coffeeTip: getFirstTip(),
          unsubscribeUrl: `${process.env.URL || "https://beanscore.netlify.app"}/.netlify/functions/unsubscribe?email=${encodeURIComponent(user.email)}`,
        });
      } catch (emailErr) {
        // A failed welcome email shouldn't roll back the actual opt-in —
        // the weekly cron will still pick them up next Monday either way.
        console.error("BeanScore: welcome email failed to send", emailErr);
      }
    }

    return json(200, { ok: true });
  } catch (e) {
    console.error("BeanScore: newsletter opt-in save failed", e);
    return json(500, { error: "Server error." });
  }
};
