// netlify/functions/send-email.js
// Shared helper: sends one email via EmailJS REST API

async function sendViaEmailJS({ templateId, toEmail, coffeeTip, unsubscribeUrl }) {
  const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      service_id: process.env.EMAILJS_SERVICE_ID, // service_dx2aicz
      template_id: templateId,
      user_id: process.env.EMAILJS_PUBLIC_KEY,
      accessToken: process.env.EMAILJS_PRIVATE_KEY,
      template_params: {
        to_email: toEmail,
        coffee_tip: coffeeTip,
        unsubscribe_url: unsubscribeUrl,
      },
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`EmailJS send failed (${response.status}): ${errText}`);
  }
  return true;
}

module.exports = { sendViaEmailJS };
