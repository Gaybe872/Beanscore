# BeanScore — Netlify Identity + Netlify DB setup

The app now has a "Sign in / Create account" option instead of the old
Firebase config paste. Three one-time steps on Netlify's side make it work
(none of this is code — it's clicking buttons in your Netlify dashboard).

## 1. Deploy this folder as a Netlify site
Drag-and-drop this whole folder into Netlify, or connect it as a Git repo.
`netlify.toml` already points Netlify at `index.html` and
`netlify/functions/`, so no build settings need changing.

## 2. Turn on Identity
Site settings → **Identity** → **Enable Identity**. That's it — the widget
script in `index.html` automatically talks to whatever site it's deployed
on, so there's nothing to paste. Optional but recommended:
Identity → **Registration** → set to *Invite only* if you don't want
strangers signing themselves up (open registration is the default).

## 3. Provision Netlify DB
Either run `netlify db init` from the CLI in this folder, or provision a
database from the Netlify dashboard (Project → Database). Either way,
Netlify sets a `NETLIFY_DATABASE_URL` environment variable for you — the
function in `netlify/functions/reviews.js` picks it up automatically via
`@netlify/neon`. Nothing to copy or paste.

## 4. Install the one dependency and deploy
```
npm install
```
then deploy (`netlify deploy --prod`, or push to your connected Git repo).
The `reviews` table is created automatically the first time anyone signs in
and the function runs — no manual migration.

## How it works
- **Auth**: Netlify Identity. Sign-in/sign-up/forgot-password is entirely
  the widget's own modal — the app just calls `netlifyIdentity.open()`.
- **Data**: one Postgres table, `reviews`, in Netlify DB. Every row is
  tagged with the signed-in user's id; the serverless function
  (`netlify/functions/reviews.js`) only ever reads/writes rows for
  whoever's Identity token is on the request, so one account's reviews
  never leak into another's.
- **Offline mode still works**: if nobody signs in, the app behaves exactly
  as before — reviews live in `localStorage` only, nothing leaves the
  device.
- **No live sync**: Postgres (via this function) doesn't push updates the
  way Firestore did, so the app re-polls every 20 seconds while signed in,
  plus immediately after you save or delete something yourself.
- **Sharing a journal**: same trick as before — have whoever you're
  sharing with sign in with the same email/password. "Copy invite for
  friends" in the sync modal drafts that message for you.

## 5. Turn on the newsletter opt-in notification email
Whenever someone ticks (or unticks) the newsletter box, the app quietly
submits that to Netlify Forms — there's a hidden `<form name="newsletter">`
near the top of `index.html` just so Netlify's build bot knows the form
exists. To actually get emailed about it:
Site settings → **Forms** → **newsletter** → **Settings and usage** →
**Add notification** → **Email notification**, and set the recipient to
`quinlansmiley@gmail.com`. That's the only step — no code, no API key.
Every submission (email address + subscribed/unsubscribed) lands in your
inbox from there. This doesn't send anything *to* subscribers — there's no
mailing list yet, just a heads-up to you when someone opts in.

## Testing locally
`netlify dev` runs the function and proxies Identity locally. Local
Identity sign-in needs the site to already be linked to a real deployed
Netlify site (`netlify link`) so it can talk to that site's real Identity
instance — there's no fully-offline Identity emulator.
